/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body (Uji Coba Teks Layar + Logika Final)
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include <stdlib.h> /* Tambahan untuk fungsi abs() */
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
char tx_buffer[100];
const int FUZZY_KP[5] = {10, 25, 50, 75, 100}; /* Matriks Kp Fuzzy */
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/
  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config(); // Fungsi ini diaktifkan lagi (Kembali ke 72MHz)

  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_ADC1_Init();
  MX_TIM1_Init();
  MX_USART2_UART_Init();

  /* USER CODE BEGIN 2 */
  // Aktifkan PWM untuk Oven dan Fan
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1); // PA8 = Oven
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2); // PA9 = Fan
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
    
    /* ------------------------------------------------------------------
     * 1. BACA SENSOR (Cara manual paling simpel & aman)
     * ------------------------------------------------------------------ */
    hadc1.Instance->SQR3 = 0; // Pilih Channel 0 (PA0)
    HAL_ADC_Start(&hadc1);
    HAL_Delay(1);
    uint32_t adc_1 = hadc1.Instance->DR;
    HAL_ADC_Stop(&hadc1);

    hadc1.Instance->SQR3 = 1; // Pilih Channel 1 (PA1)
    HAL_ADC_Start(&hadc1);
    HAL_Delay(1);
    uint32_t adc_2 = hadc1.Instance->DR;
    HAL_ADC_Stop(&hadc1);

    /* Konversi ke Celcius (Gunakan 500U karena Proteus Vref-nya 5.0V) */
    int t1 = (int)((adc_1 * 500U) / 4095U);
    int t2 = (int)((adc_2 * 500U) / 4095U);
    int selisih = abs(t1 - t2);

    int pwm_heater = 0;
    int pwm_fan = 0;

    /* ------------------------------------------------------------------
     * 2. LOGIKA OVEN & FAN
     * ------------------------------------------------------------------ */
    if ((t1 >= 80) || (t2 >= 80) || (selisih >= 15)) 
    {
        // KONDISI BAHAYA: Oven Mati, Fan Nyala 100% (ARR = 1000)
        pwm_heater = 0;
        pwm_fan = 1000;
    }
    else 
    {
        // KONDISI AMAN: Fan Mati, Oven diatur PID
        pwm_fan = 0;
        
        int t_avg = (t1 + t2) / 2;
        int error = 50 - t_avg; // Setpoint 50 derajat

        if (error > 0)
        {
            int index = error / 10;
            if (index > 4) index = 4; // Batas maksimal array
            pwm_heater = (1000 * FUZZY_KP[index]) / 100;
        }
        else
        {
            pwm_heater = 0; // Jika suhu sudah 50, oven istirahat
        }
    }

    /* ------------------------------------------------------------------
     * 3. JALANKAN HARDWARE (PWM)
     * ------------------------------------------------------------------ */
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, pwm_heater);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, pwm_fan);

    /* ------------------------------------------------------------------
     * 4. TEMBAK DATA KE LAYAR PROTEUS
     * ------------------------------------------------------------------ */
    sprintf(tx_buffer, "Suhu1: %dC | Suhu2: %dC | Oven: %d | Fan: %d\r\n", t1, t2, pwm_heater, pwm_fan);
    HAL_UART_Transmit(&huart2, (uint8_t*)tx_buffer, strlen(tx_buffer), HAL_MAX_DELAY);
    
    // Jeda 200ms agar layar Proteus gampang dibaca
    HAL_Delay(200);

  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC;
  PeriphClkInit.AdcClockSelection = RCC_ADCPCLK2_DIV6;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  __disable_irq();
  while (1)
  {
  }
}

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
}
#endif /* USE_FULL_ASSERT */